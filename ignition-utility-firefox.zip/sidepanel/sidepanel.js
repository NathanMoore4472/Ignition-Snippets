const outputEl = document.getElementById('output');

// ── Port ──────────────────────────────────────────────────────────────────────

const _port = browser.runtime.connect({ name: 'sidepanel' });
console.log('[IU] sidebar connected port');
browser.windows.getCurrent().then((win) => {
  console.log('[IU] sidebar in window:', win?.id);
  if (win) _port.postMessage({ windowId: win.id });
});

// ── Page Detection ────────────────────────────────────────────────────────────

async function detectPageType() {
  const response = await send({ type: 'DETECT_PAGE' });
  const pageType = response?.success ? response.result : 'unknown';
  document.body.dataset.pageType = pageType;
  const badge = document.getElementById('pageBadge');
  if (pageType !== 'unknown') {
    badge.textContent = pageType === 'gateway' ? 'Gateway' : 'Perspective';
    badge.className = `page-badge ${pageType}`;
  } else {
    badge.textContent = '';
    badge.className = 'page-badge hidden';
  }
  // If we're on a non-perspective page, switch to Actions tab
  if (pageType !== 'perspective') switchTab('actions');
}

detectPageType();

browser.tabs.onActivated.addListener(() => detectPageType());
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.active && changeInfo.status === 'complete') detectPageType();
});

document.getElementById('showAnyway').addEventListener('click', () => {
  document.body.dataset.pageType = 'override';
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function send(msg) {
  return browser.runtime.sendMessage(msg);
}

function formatValue(value) {
  if (value === null || value === undefined) return String(value);
  if (typeof value === 'object') return JSON.stringify(value, null, 2);
  return String(value);
}

function parseValue(raw) {
  try { return JSON.parse(raw); } catch { return raw; }
}

function createOutputEntry(label, isError = false) {
  const ts = new Date().toLocaleTimeString();
  outputEl.querySelector('.output-placeholder')?.remove();
  const entry = document.createElement('div');
  entry.className = 'output-entry';
  const header = document.createElement('div');
  header.className = isError ? 'output-label output-label-error' : 'output-label';
  header.textContent = `${isError ? '✗' : '✓'} [${ts}] ${label}`;
  entry.appendChild(header);
  outputEl.insertBefore(entry, outputEl.firstChild);
  return entry;
}

function appendOutput(label, value, isError = false) {
  const entry = createOutputEntry(label, isError);
  const body = document.createElement('pre');
  body.className = 'output-text';
  body.textContent = formatValue(value);
  entry.appendChild(body);
}

// ── Tree renderer ─────────────────────────────────────────────────────────────

const TREE_SCRIPTS = new Set(['readPageProps', 'readSessionProps']);

function appendTreeOutput(label, value) {
  const entry = createOutputEntry(label);
  const root = document.createElement('div');
  root.className = 'tree-root';
  if (value !== null && typeof value === 'object') {
    const pairs = Array.isArray(value) ? value.map((v, i) => [String(i), v]) : Object.entries(value);
    pairs.forEach(([k, v]) => {
      root.appendChild(
        v !== null && typeof v === 'object' ? buildTreeNode(k, v) : buildLeaf(k, v)
      );
    });
  } else {
    root.appendChild(buildLeaf(null, value));
  }
  entry.appendChild(root);
}

function buildTreeNode(key, value) {
  const isArr = Array.isArray(value);
  const pairs = isArr ? value.map((v, i) => [String(i), v]) : Object.entries(value);

  const wrap = document.createElement('div');
  wrap.className = 'tree-node';

  const header = document.createElement('div');
  header.className = 'tree-header';

  const arrow = document.createElement('span');
  arrow.className = 'tree-arrow';
  arrow.textContent = '▶';

  const keyEl = document.createElement('span');
  keyEl.className = 'tree-key';
  keyEl.textContent = key + ': ';

  const summary = document.createElement('span');
  summary.className = 'tree-summary';
  summary.textContent = isArr ? `[${pairs.length}]` : `{${pairs.length}}`;

  header.append(arrow, keyEl, summary);

  const children = document.createElement('div');
  children.className = 'tree-children';

  pairs.forEach(([k, v]) => {
    children.appendChild(
      v !== null && typeof v === 'object' ? buildTreeNode(k, v) : buildLeaf(k, v)
    );
  });

  header.addEventListener('click', () => {
    const open = children.classList.toggle('tree-open');
    arrow.textContent = open ? '▼' : '▶';
    summary.hidden = open;
  });

  wrap.append(header, children);
  return wrap;
}

function buildLeaf(key, value) {
  const row = document.createElement('div');
  row.className = 'tree-leaf';
  if (key !== null) {
    const k = document.createElement('span');
    k.className = 'tree-key';
    k.textContent = key + ': ';
    row.appendChild(k);
  }
  const v = document.createElement('span');
  const type = value === null ? 'null' : typeof value;
  v.className = `tree-val tree-${type}`;
  v.textContent = JSON.stringify(value);
  row.appendChild(v);
  return row;
}

// ── Tabs ──────────────────────────────────────────────────────────────────────

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('hidden', p.id !== `panel-${name}`));
  document.body.dataset.activeTab = name;
}

document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ── Quick Actions ─────────────────────────────────────────────────────────────

document.querySelectorAll('[data-script]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const script = btn.dataset.script;
    const confirmMsg = btn.dataset.confirm;
    if (confirmMsg && !confirm(confirmMsg)) return;
    const label = btn.textContent.trim();
    btn.disabled = true;
    const configFn = DEBUG_CONFIG_MAP[script];
    const response = await send({ type: 'EXECUTE_SCRIPT', script, ...(configFn ? { args: [configFn()] } : {}) });
    btn.disabled = false;
    if (response.success) {
      if (TREE_SCRIPTS.has(script) && response.result !== null && typeof response.result === 'object') {
        appendTreeOutput(label, response.result);
      } else {
        appendOutput(label, response.result ?? 'Done');
      }
    } else {
      appendOutput(label, response.error, true);
    }
  });
});

// ── Props Tab ─────────────────────────────────────────────────────────────────

const propsMountPathInput = document.getElementById('propsMountPath');
const propsViewSelect = document.getElementById('propsViewSelect');
const paramsSelect = document.getElementById('paramsSelect');
const paramsValueInput = document.getElementById('paramsValue');
const customPropsSelect = document.getElementById('customPropsSelect');
const customPropsValueInput = document.getElementById('customPropsValue');

let loadedParams = {};
let loadedCustom = {};

// View picker
document.getElementById('propsPickView').addEventListener('click', async () => {
  const btn = document.getElementById('propsPickView');
  btn.disabled = true;
  btn.textContent = '…';
  const response = await send({ type: 'EXECUTE_SCRIPT', script: 'getViews' });
  btn.disabled = false;
  btn.textContent = 'Views ▾';
  if (!response.success) { appendOutput('Get Views', response.error, true); return; }
  const views = response.result ?? [];
  propsViewSelect.innerHTML = '<option value="">— select a view —</option>';
  views.forEach(({ mountPath, resourcePath }) => {
    const opt = document.createElement('option');
    opt.value = mountPath;
    opt.textContent = resourcePath ? `${resourcePath} (${mountPath})` : mountPath;
    propsViewSelect.appendChild(opt);
  });
  propsViewSelect.classList.toggle('hidden', views.length === 0);
});

propsViewSelect.addEventListener('change', () => {
  if (propsViewSelect.value) propsMountPathInput.value = propsViewSelect.value;
});

// Load props
document.getElementById('propsLoad').addEventListener('click', async () => {
  const mountPath = propsMountPathInput.value.trim();
  if (!mountPath) { appendOutput('Load Props', 'Mount path is required.', true); return; }

  const [paramsResp, customResp] = await Promise.all([
    send({ type: 'READ_PARAMS', mountPath }),
    send({ type: 'READ_PROP', mountPath, propPath: '' }),
  ]);

  // Populate params dropdown
  loadedParams = paramsResp.success ? (paramsResp.result ?? {}) : {};
  paramsSelect.innerHTML = '<option value="">— select param —</option>';
  Object.keys(loadedParams).forEach((key) => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = key;
    paramsSelect.appendChild(opt);
  });
  if (!paramsResp.success) appendOutput('Load Params', paramsResp.error, true);

  // Populate custom props dropdown
  loadedCustom = customResp.success ? (customResp.result ?? {}) : {};
  customPropsSelect.innerHTML = '<option value="">— select prop —</option>';
  Object.keys(loadedCustom).forEach((key) => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = key;
    customPropsSelect.appendChild(opt);
  });
  if (!customResp.success) appendOutput('Load Custom Props', customResp.error, true);
});

// Dropdown → value fill
paramsSelect.addEventListener('change', () => {
  if (!paramsSelect.value) { paramsValueInput.value = ''; return; }
  const val = loadedParams[paramsSelect.value];
  paramsValueInput.value = val !== undefined
    ? (typeof val === 'object' ? JSON.stringify(val, null, 2) : String(val))
    : '';
});

customPropsSelect.addEventListener('change', () => {
  if (!customPropsSelect.value) { customPropsValueInput.value = ''; return; }
  const val = loadedCustom[customPropsSelect.value];
  customPropsValueInput.value = val !== undefined
    ? (typeof val === 'object' ? JSON.stringify(val, null, 2) : String(val))
    : '';
});

// Write custom prop
document.getElementById('writeCustomProp').addEventListener('click', async () => {
  const mountPath = propsMountPathInput.value.trim();
  const propPath = customPropsSelect.value;
  if (!mountPath || !propPath) { appendOutput('Write Custom Prop', 'Select a view and prop first.', true); return; }
  const response = await send({ type: 'WRITE_PROP', mountPath, propPath, value: parseValue(customPropsValueInput.value.trim()) });
  if (response.success) {
    appendOutput(`Write custom ${propPath} @ ${mountPath}`, response.result);
  } else {
    appendOutput('Write Custom Prop', response.error, true);
  }
});

// ── Settings ──────────────────────────────────────────────────────────────────

const fabToggle = document.getElementById('fabToggle');
browser.storage.sync.get('fabEnabled').then(({ fabEnabled = true }) => {
  fabToggle.checked = fabEnabled;
});
fabToggle.addEventListener('change', () => {
  browser.storage.sync.set({ fabEnabled: fabToggle.checked });
});

// ── Debug Settings ────────────────────────────────────────────────────────────

const DEBUG_DEFAULTS = {
  outlineColor:   '#ff6400',
  outlineOpacity: 0.55,
  overflowColor:  '#ff2828',
  overflowOpacity: 0.9,
  depthOpacity:   0.1,
};

let debugConfig = { ...DEBUG_DEFAULTS };

const DEBUG_CONTROLS = [
  { id: 'outlineColor',    key: 'outlineColor',    type: 'color' },
  { id: 'outlineOpacity',  key: 'outlineOpacity',  type: 'range', valId: 'outlineOpacityVal'  },
  { id: 'overflowColor',   key: 'overflowColor',   type: 'color' },
  { id: 'overflowOpacity', key: 'overflowOpacity', type: 'range', valId: 'overflowOpacityVal' },
  { id: 'depthOpacity',    key: 'depthOpacity',    type: 'range', valId: 'depthOpacityVal'    },
];

browser.storage.sync.get(Object.keys(DEBUG_DEFAULTS)).then((stored) => {
  DEBUG_CONTROLS.forEach(({ id, key, type, valId }) => {
    const el = document.getElementById(id);
    if (!el) return;
    const val = stored[key] ?? DEBUG_DEFAULTS[key];
    debugConfig[key] = val;
    el.value = val;
    if (valId) document.getElementById(valId).textContent = parseFloat(val).toFixed(2);
  });
});

DEBUG_CONTROLS.forEach(({ id, key, type, valId }) => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input', () => {
    const val = type === 'range' ? parseFloat(el.value) : el.value;
    debugConfig[key] = val;
    if (valId) document.getElementById(valId).textContent = typeof val === 'number' ? val.toFixed(2) : val;
    browser.storage.sync.set({ [key]: val });
  });
});

const DEBUG_CONFIG_MAP = {
  toggleOutlines:     () => ({ color: debugConfig.outlineColor,  opacity: debugConfig.outlineOpacity }),
  toggleOverflow:     () => ({ color: debugConfig.overflowColor, opacity: debugConfig.overflowOpacity }),
  toggleDepthOverlay: () => ({ opacity: debugConfig.depthOpacity }),
};

// ── Clear Output ──────────────────────────────────────────────────────────────

document.getElementById('clearOutput').addEventListener('click', () => {
  outputEl.innerHTML = '<div class="output-placeholder">— results will appear here —</div>';
});
