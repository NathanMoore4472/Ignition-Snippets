const statusEl = document.getElementById('status');

(async () => {
  const response = await browser.runtime.sendMessage({ type: 'DETECT_PAGE' });
  const pageType = response?.success ? response.result : 'unknown';
  document.body.dataset.pageType = pageType;
  if (pageType !== 'unknown') {
    const badge = document.getElementById('pageBadge');
    badge.textContent = pageType === 'gateway' ? 'Gateway' : 'Perspective';
    badge.className = `page-badge ${pageType}`;
  }
})();

function setStatus(text, type = 'info') {
  statusEl.textContent = text;
  statusEl.className = `status ${type}`;
}

function clearStatus() {
  statusEl.className = 'status hidden';
}

async function runScript(scriptName) {
  return browser.runtime.sendMessage({ type: 'EXECUTE_SCRIPT', script: scriptName });
}

document.querySelectorAll('[data-script]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const script = btn.dataset.script;
    const confirmMsg = btn.dataset.confirm;

    if (confirmMsg && !confirm(confirmMsg)) return;

    btn.disabled = true;
    setStatus('Running…', 'info');

    const response = await runScript(script);

    btn.disabled = false;

    if (response.success) {
      setStatus('Done', 'success');
    } else {
      setStatus(`Error: ${response.error}`, 'error');
    }
  });
});

const fabToggle = document.getElementById('fabToggle');
browser.storage.sync.get('fabEnabled').then(({ fabEnabled = true }) => {
  fabToggle.checked = fabEnabled;
});
fabToggle.addEventListener('change', () => {
  browser.storage.sync.set({ fabEnabled: fabToggle.checked });
});

document.getElementById('showAnyway').addEventListener('click', () => {
  document.body.dataset.pageType = 'override';
});

document.getElementById('openSidePanel').addEventListener('click', async () => {
  // Firefox sidebar requires user gesture context to open
  await browser.sidebarAction.open();
  window.close();
});
