// Script functions executed in the page's MAIN world.
// These are serialized and sent via browser.scripting.executeScript,
// so they cannot reference anything outside their own function body.

const SCRIPTS = {
  showRestartBanner: () => {
    if (window.__ignitionUtility_bannerPatched) {
      return { message: "Banner interceptor already active." };
    }
    const _fetch = window.fetch;
    window.fetch = function (input, init) {
      const url = typeof input === "string" ? input : input.url;
      if (url && url.includes("/overview/banners")) {
        return Promise.resolve(
          new Response(
            JSON.stringify({
              banners: [
                {
                  order: 1,
                  type: "restart-required",
                  data: { severity: "info", toolTips: [], actions: [] },
                },
              ],
            }),
            { status: 200, headers: { "Content-Type": "application/json" } },
          ),
        );
      }
      return _fetch.apply(this, arguments);
    };
    window.__ignitionUtility_bannerPatched = true;
    return {
      message:
        "Restart banner interceptor active. Reload the page to see the banner.",
    };
  },

  restartGateway: () => {
    return System.import("@inductiveautomation/ignition-gateway-lib").then(
      (lib) => {
        const banner = document.querySelector(
          '[class*="Banner"], [class*="banner"]',
        );
        if (!banner) throw new Error("Banner element not found");
        const key = Object.keys(banner).find((k) =>
          k.startsWith("__reactFiber"),
        );
        if (!key) throw new Error("React fiber not found on Banner element");
        let fiber = banner[key];
        while (fiber && fiber.return) fiber = fiber.return;
        function findStore(n, d = 0) {
          if (!n || d > 100) return null;
          if (n.memoizedProps && n.memoizedProps.store)
            return n.memoizedProps.store;
          return findStore(n.child, d + 1) || findStore(n.sibling, d);
        }
        const store = findStore(fiber);
        if (!store) throw new Error("Redux store not found");
        store.dispatch(
          lib.BaseApi.endpoints.restartGateway.initiate({ confirm: true }),
        );
        return { message: "Gateway restart dispatched." };
      },
    );
  },

  scanConfig: () => {
    function findScanApi() {
      if (!System.entries) throw new Error("SystemJS entries not available");
      for (const [, mod] of System.entries()) {
        if (!mod || typeof mod !== "object") continue;
        for (const val of Object.values(mod)) {
          if (
            val &&
            val.endpoints &&
            val.endpoints.requestConfigurationSync &&
            val.endpoints.getSyncStatus
          )
            return val;
        }
      }
      throw new Error("ScanFileSystem API not found in loaded modules");
    }
    const api = findScanApi();
    const banner = document.querySelector(
      '[class*="Banner"], [class*="banner"]',
    );
    if (!banner) throw new Error("Banner element not found");
    const key = Object.keys(banner).find((k) => k.startsWith("__reactFiber"));
    if (!key) throw new Error("React fiber not found");
    let fiber = banner[key];
    while (fiber && fiber.return) fiber = fiber.return;
    function findStore(n, d = 0) {
      if (!n || d > 100) return null;
      if (n.memoizedProps && n.memoizedProps.store)
        return n.memoizedProps.store;
      return findStore(n.child, d + 1) || findStore(n.sibling, d);
    }
    const store = findStore(fiber);
    if (!store) throw new Error("Redux store not found");
    return store
      .dispatch(api.endpoints.requestConfigurationSync.initiate("config"))
      .unwrap()
      .then(async (res) => {
        if (!res.scanActive) return { message: "Config scan complete." };
        while (true) {
          await new Promise((r) => setTimeout(r, 5000));
          const status = await store
            .dispatch(api.endpoints.getSyncStatus.initiate("config"))
            .unwrap();
          if (!status.scanActive) return { message: "Config scan complete." };
        }
      });
  },

  scanProjects: () => {
    function findScanApi() {
      if (!System.entries) throw new Error("SystemJS entries not available");
      for (const [, mod] of System.entries()) {
        if (!mod || typeof mod !== "object") continue;
        for (const val of Object.values(mod)) {
          if (
            val &&
            val.endpoints &&
            val.endpoints.requestConfigurationSync &&
            val.endpoints.getSyncStatus
          )
            return val;
        }
      }
      throw new Error("ScanFileSystem API not found in loaded modules");
    }
    const api = findScanApi();
    const banner = document.querySelector(
      '[class*="Banner"], [class*="banner"]',
    );
    if (!banner) throw new Error("Banner element not found");
    const key = Object.keys(banner).find((k) => k.startsWith("__reactFiber"));
    if (!key) throw new Error("React fiber not found");
    let fiber = banner[key];
    while (fiber && fiber.return) fiber = fiber.return;
    function findStore(n, d = 0) {
      if (!n || d > 100) return null;
      if (n.memoizedProps && n.memoizedProps.store)
        return n.memoizedProps.store;
      return findStore(n.child, d + 1) || findStore(n.sibling, d);
    }
    const store = findStore(fiber);
    if (!store) throw new Error("Redux store not found");
    return store
      .dispatch(api.endpoints.requestConfigurationSync.initiate("projects"))
      .unwrap()
      .then(async (res) => {
        if (!res.scanActive) return { message: "Projects scan complete." };
        while (true) {
          await new Promise((r) => setTimeout(r, 5000));
          const status = await store
            .dispatch(api.endpoints.getSyncStatus.initiate("projects"))
            .unwrap();
          if (!status.scanActive) return { message: "Projects scan complete." };
        }
      });
  },

  readPageProps: () => {
    return window.__client.page.pageProps.read();
  },

  readSessionProps: () => {
    return window.__client.page.sessionCustom.read();
  },

  getViews: () => {
    const views = window.__client.page.views;
    return Array.from(views._data.values()).map((v) => ({
      mountPath: v.value.mountPath,
      resourcePath: v.value.resourcePath ?? null,
    }));
  },

  toggleOutlines: (config) => {
    function h2r(hex) {
      return [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16)];
    }
    const [r,g,b] = h2r((config && config.color) || "#ff6400");
    const op = (config && config.opacity != null) ? config.opacity : 0.55;
    const ID = "__iu-outlines";
    const existing = document.getElementById(ID);
    if (existing) {
      existing.remove();
      return { message: "Element outlines removed." };
    }
    const style = document.createElement("style");
    style.id = ID;
    style.textContent = `* { outline: 1px solid rgba(${r},${g},${b},${op}) !important; }`;
    document.head.appendChild(style);
    return { message: "Element outlines active." };
  },

  toggleOverflow: (config) => {
    function h2r(hex) {
      return [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16)];
    }
    const [r,g,b] = h2r((config && config.color) || "#ff2828");
    const op = (config && config.opacity != null) ? config.opacity : 0.9;
    const fillOp = Math.round(op * 6.7) / 100;
    const STYLE_ID = "__iu-overflow-style";
    const CLS = "__iu-overflow";
    if (document.getElementById(STYLE_ID)) {
      document.getElementById(STYLE_ID).remove();
      document
        .querySelectorAll("." + CLS)
        .forEach((el) => el.classList.remove(CLS));
      return { message: "Overflow highlights removed." };
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `.${CLS} { outline: 2px solid rgba(${r},${g},${b},${op}) !important; background-color: rgba(${r},${g},${b},${fillOp}) !important; }`;
    document.head.appendChild(style);
    let count = 0;
    document.querySelectorAll("*").forEach((el) => {
      if (
        el.scrollWidth > el.clientWidth + 1 ||
        el.scrollHeight > el.clientHeight + 1
      ) {
        el.classList.add(CLS);
        count++;
      }
    });
    return { message: count + " overflowing element(s) highlighted." };
  },

  toggleDepthOverlay: (config) => {
    const op = (config && config.opacity != null) ? config.opacity : 0.1;
    const STYLE_ID = "__iu-depth-style";
    const PREFIX = "__iu-d";
    if (document.getElementById(STYLE_ID)) {
      document.getElementById(STYLE_ID).remove();
      document.querySelectorAll('[class*="' + PREFIX + '"]').forEach((el) => {
        el.className = el.className
          .split(" ")
          .filter((c) => !c.startsWith(PREFIX))
          .join(" ");
      });
      return { message: "Depth overlay removed." };
    }
    const hues = [[255,80,80],[60,200,60],[60,80,255],[255,200,40],[200,60,255],[40,200,220]];
    const style = document.createElement("style");
    style.id = STYLE_ID;
    hues.forEach(([hr,hg,hb], i) => {
      style.textContent += `.${PREFIX}${i}{background-color:rgba(${hr},${hg},${hb},${op})!important}`;
    });
    document.head.appendChild(style);
    function depth(el) {
      let d = 0, p = el.parentElement;
      while (p) { d++; p = p.parentElement; }
      return d;
    }
    document
      .querySelectorAll("*:not(script):not(style):not(head):not(link)")
      .forEach((el) => {
        el.classList.add(PREFIX + (depth(el) % hues.length));
      });
    return { message: "Depth overlay active." };
  },

  getMainView: () => {
    const view = Array.from(window.__client.page.views._data.values()).find(
      (v) => v.value.mountPath === "C$0:0",
    );
    if (!view) return null;
    return view.value.custom.read();
  },
};

// Firefox sidebar state tracking (per-window, not per-tab like Chrome)
const sidebarOpenWindows = new Set();

browser.runtime.onConnect.addListener((port) => {
  if (port.name !== "sidepanel") return;
  console.log("[IU] sidebar port connected");
  let windowId = null;
  port.onMessage.addListener((msg) => {
    if (msg.windowId) {
      windowId = msg.windowId;
      sidebarOpenWindows.add(windowId);
      console.log(`[IU] sidebar open for window ${windowId}`, sidebarOpenWindows);
    }
  });
  port.onDisconnect.addListener(() => {
    console.log(`[IU] sidebar port disconnected, windowId=${windowId}`);
    if (windowId) sidebarOpenWindows.delete(windowId);
  });
});

async function getActiveTabId() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  return tab?.id ?? null;
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "OPEN_SIDE_PANEL") {
      // Firefox requires sidebarAction.open/close to be called from a user gesture.
      // When called via message passing from a content script, the gesture context is lost.
      // We can only check if the sidebar is open and inform the user.
      const windowId = sender?.tab?.windowId;
      console.log(`[IU] OPEN_SIDE_PANEL windowId=${windowId}`);
      if (windowId) {
        const isOpen = await browser.sidebarAction.isOpen({ windowId });
        if (isOpen) {
          // Can't close programmatically - just inform the caller
          sendResponse({ success: true, alreadyOpen: true });
        } else {
          // Try to open - this may fail without user gesture context
          try {
            await browser.sidebarAction.open();
            sendResponse({ success: true });
          } catch (err) {
            // Gesture context lost - tell user to use toolbar button or keyboard shortcut
            console.log("[IU] Cannot open sidebar without user gesture:", err.message);
            sendResponse({
              success: false,
              error: "Use the toolbar button or Ctrl+Shift+Y to open the sidebar"
            });
          }
        }
      } else {
        sendResponse({ success: true });
      }
      return;
    }

    const tabId = await getActiveTabId();
    if (!tabId) {
      sendResponse({ success: false, error: "No active tab found." });
      return;
    }

    try {
      if (message.type === "EXECUTE_SCRIPT") {
        const func = SCRIPTS[message.script];
        if (!func) throw new Error(`Unknown script: ${message.script}`);
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func,
          args: message.args ?? [],
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result });
      } else if (message.type === "READ_PROP") {
        const { mountPath, propPath } = message;
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func: (mountPath, propPath) => {
            const view = Array.from(
              window.__client.page.views._data.values(),
            ).find((v) => v.value.mountPath === mountPath);
            if (!view) throw new Error(`View not found: ${mountPath}`);
            return propPath
              ? view.value.custom.read(propPath)
              : view.value.custom.read();
          },
          args: [mountPath, propPath],
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result });
      } else if (message.type === "WRITE_PROP") {
        const { mountPath, propPath, value } = message;
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func: (mountPath, propPath, value) => {
            const view = Array.from(
              window.__client.page.views._data.values(),
            ).find((v) => v.value.mountPath === mountPath);
            if (!view) throw new Error(`View not found: ${mountPath}`);
            view.value.custom.write(propPath, value);
            return { message: `Wrote to ${propPath} on ${mountPath}` };
          },
          args: [mountPath, propPath, value],
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result });
      } else if (message.type === "READ_PARAMS") {
        const { mountPath } = message;
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func: (mountPath) => {
            const view = Array.from(
              window.__client.page.views._data.values(),
            ).find((v) => v.value.mountPath === mountPath);
            if (!view) throw new Error(`View not found: ${mountPath}`);
            const map = view.value.params.root.value.value;
            const out = {};
            map.forEach((entry, key) => {
              out[key] = entry.value.value;
            });
            return out;
          },
          args: [mountPath],
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result });
      } else if (message.type === "WRITE_PARAM") {
        const { mountPath, propPath, value } = message;
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func: (mountPath, propPath, value) => {
            const view = Array.from(
              window.__client.page.views._data.values(),
            ).find((v) => v.value.mountPath === mountPath);
            if (!view) throw new Error(`View not found: ${mountPath}`);
            view.value.params.write(propPath, value);
            return { message: `Wrote param ${propPath} on ${mountPath}` };
          },
          args: [mountPath, propPath, value],
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result });
      } else if (message.type === "DETECT_PAGE") {
        const [result] = await browser.scripting.executeScript({
          target: { tabId },
          func: () => {
            if (typeof window.__client !== "undefined") return "perspective";
            if (
              typeof System !== "undefined" &&
              typeof System.import === "function"
            )
              return "gateway";
            return "unknown";
          },
          world: "MAIN",
        });
        sendResponse({ success: true, result: result?.result ?? "unknown" });
      } else {
        sendResponse({
          success: false,
          error: `Unknown message type: ${message.type}`,
        });
      }
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  })();

  return true; // Keep the message channel open for async response
});
