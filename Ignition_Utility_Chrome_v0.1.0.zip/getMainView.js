window.__client.page.views._data
  .values()
  .find((view) => view.value.mountPath == "C$0:0");
