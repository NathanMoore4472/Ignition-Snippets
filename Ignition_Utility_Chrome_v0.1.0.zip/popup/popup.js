const statusEl = document.getElementById('status');

(async () => {
  const response = await chrome.runtime.sendMessage({ type: 'DETECT_PAGE' });
  const pageType = response?.success ? response.result : 'unknown';
  document.body.dataset.pageType = pageType;
  if (pageType !== 'unknown') {
    const badge = document.getElementById('pageBadge');
    badge.textContent = pageType === 'gateway' ? 'Gateway' : 'Perspective';
    badge.className = `page-badge ${pageType}`;
  }
})();

function setStatus(text, type = 'info') {
  statusEl.textContent = text;
  statusEl.className = `status ${type}`;
}

function clearStatus() {
  statusEl.className = 'status hidden';
}

async function runScript(scriptName, args) {
  return chrome.runtime.sendMessage({ type: 'EXECUTE_SCRIPT', script: scriptName, ...(args ? { args: [args] } : {}) });
}

// Debug config (loaded from storage)
const DEBUG_DEFAULTS = {
  outlineColor: '#ff6400',
  outlineOpacity: 0.55,
  overflowColor: '#ff2828',
  overflowOpacity: 0.9,
  depthOpacity: 0.1,
};

let debugConfig = { ...DEBUG_DEFAULTS };

chrome.storage.sync.get(Object.keys(DEBUG_DEFAULTS), (stored) => {
  Object.keys(DEBUG_DEFAULTS).forEach((key) => {
    debugConfig[key] = stored[key] ?? DEBUG_DEFAULTS[key];
  });
});

const DEBUG_CONFIG_MAP = {
  toggleOutlines: () => ({ color: debugConfig.outlineColor, opacity: debugConfig.outlineOpacity }),
  toggleOverflow: () => ({ color: debugConfig.overflowColor, opacity: debugConfig.overflowOpacity }),
  toggleDepthOverlay: () => ({ opacity: debugConfig.depthOpacity }),
};

document.querySelectorAll('[data-script]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const script = btn.dataset.script;
    const confirmMsg = btn.dataset.confirm;

    if (confirmMsg && !confirm(confirmMsg)) return;

    btn.disabled = true;
    setStatus('Running…', 'info');

    const configFn = DEBUG_CONFIG_MAP[script];
    const response = await runScript(script, configFn ? configFn() : undefined);

    btn.disabled = false;

    if (response.success) {
      setStatus('Done', 'success');
    } else {
      setStatus(`Error: ${response.error}`, 'error');
    }
  });
});

const fabToggle = document.getElementById('fabToggle');
chrome.storage.sync.get('fabEnabled', ({ fabEnabled = true }) => {
  fabToggle.checked = fabEnabled;
});
fabToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ fabEnabled: fabToggle.checked });
});

document.getElementById('showAnyway').addEventListener('click', () => {
  document.body.dataset.pageType = 'override';
});

document.getElementById('openSidePanel').addEventListener('click', async () => {
  // Must be called directly in response to a user gesture — routing through
  // the background service worker loses the gesture context and silently fails.
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.sidePanel.open({ tabId: tab.id });
  window.close();
});
