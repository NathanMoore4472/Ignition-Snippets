expandedLog(window.__client.page.sessionCustom.read());
