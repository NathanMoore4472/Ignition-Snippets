const _fetch = window.fetch;
window.fetch = function (input, init) {
  const url = typeof input === "string" ? input : input.url;
  if (url && url.includes("/overview/banners")) {
    return Promise.resolve(
      new Response(
        JSON.stringify({
          banners: [
            {
              order: 1,
              type: "restart-required",
              data: { severity: "info", toolTips: [], actions: [] },
            },
          ],
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      ),
    );
  }
  return _fetch.apply(this, arguments);
};
