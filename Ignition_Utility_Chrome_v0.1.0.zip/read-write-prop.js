// Need to get a view first from getViews.js or getMainView.js
view.value.custom.write("test", 2);
view.value.custom.read("test");
