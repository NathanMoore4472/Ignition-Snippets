System.import("@inductiveautomation/ignition-gateway-lib").then((lib) => {
  // Get the Redux store via React fiber on the Banner element
  const banner = document.querySelector('[class*="Banner"], [class*="banner"]');
  const key = Object.keys(banner).find((k) => k.startsWith("__reactFiber"));
  let fiber = banner[key];
  while (fiber && fiber.return) fiber = fiber.return;
  function findStore(n, d = 0) {
    if (!n || d > 100) return null;
    if (n.memoizedProps && n.memoizedProps.store) return n.memoizedProps.store;
    return findStore(n.child, d + 1) || findStore(n.sibling, d);
  }
  const store = findStore(fiber);
  // Dispatch the restartGateway mutation (same as clicking "Restart Gateway" in the UI)
  store.dispatch(
    lib.BaseApi.endpoints.restartGateway.initiate({ confirm: true }),
  );
});
