let currentPageType = "unknown";

async function init() {
  const { fabEnabled = true } = await chrome.storage.sync.get("fabEnabled");
  if (!fabEnabled) return;

  for (const delay of [0, 1000, 3000]) {
    if (delay) await new Promise((r) => setTimeout(r, delay));
    const response = await chrome.runtime.sendMessage({ type: "DETECT_PAGE" });
    currentPageType = response?.success ? response.result : "unknown";
    if (currentPageType !== "unknown") {
      injectFab();
      return;
    }
  }
}

function injectFab() {
  if (document.getElementById("__iu-fab-host")) return;

  const host = document.createElement("div");
  host.id = "__iu-fab-host";
  const shadow = host.attachShadow({ mode: "closed" });

  const style = document.createElement("style");
  style.textContent = `
    button {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 44px;
      height: 44px;
      border-radius: 50%;
      border: none;
      background: #28c878;
      cursor: pointer;
      opacity: 0.2;
      transition: opacity 0.2s, transform 0.15s, box-shadow 0.2s;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      padding: 0;
    }
    button:hover {
      opacity: 1;
      transform: scale(1.08);
      box-shadow: 0 4px 16px rgba(14, 232, 10, 0.45);
    }
    button:active {
      transform: scale(0.94);
    }
  `;

  const btn = document.createElement("button");
  btn.title = "Ignition Utility";
  btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`;
  btn.addEventListener("click", () => {
    try {
      chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" });
    } catch {
      // Extension was reloaded; remove the stale FAB — page refresh will restore it
      removeFab();
    }
  });

  shadow.appendChild(style);
  shadow.appendChild(btn);
  document.body.appendChild(host);
}

function removeFab() {
  document.getElementById("__iu-fab-host")?.remove();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync" || !("fabEnabled" in changes)) return;
  if (changes.fabEnabled.newValue && currentPageType !== "unknown") {
    injectFab();
  } else {
    removeFab();
  }
});

init();
